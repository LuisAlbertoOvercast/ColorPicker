import * as React from 'react';
import { IInputs } from '../generated/ManifestTypes';
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button'
import { mergeStyleSets } from 'office-ui-fabric-react/lib/Styling'
import { ColorPicker, IColor, IStackItemStyles, DefaultPalette } from '@fluentui/react';
import { Panel } from 'office-ui-fabric-react/lib/Panel'

export interface Iprops {
  isOpen: any,
  dismissPanel: any,
  onRenderFooterContent: any,
  color: any,
  _updateColor: any
}

export const PanelButton: React.FC<Iprops> = ({isOpen, dismissPanel, onRenderFooterContent, color, _updateColor}) => {

  return (
        <Panel
          isOpen={isOpen}
          onDismiss={dismissPanel}
          headerText="Seleccionar color"
          onRenderFooterContent={onRenderFooterContent}
          isFooterAtBottom={true}
          type={1}
        >
          <div className="">
            <ColorPicker
              color={color}
              alphaType="none"
              onChange={_updateColor}
            />
          </div>
          <div className=""/>
        </Panel>
  
  );
};

