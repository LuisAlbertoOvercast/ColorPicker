import * as React from 'react';
import { IInputs } from '../generated/ManifestTypes';
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button'
import { mergeStyleSets } from 'office-ui-fabric-react/lib/Styling'
import { ColorPicker, IColor, IStackItemStyles, DefaultPalette } from '@fluentui/react';
import { Panel } from 'office-ui-fabric-react/lib/Panel'
import {PanelButton} from './PanelButton'

export interface Iprops {
  pcfContext: ComponentFramework.Context<IInputs>,
  color: string,
  updateColor: (_color: string) => void
}

export const SelectColorButton: React.FC<Iprops> = (props) => {
  const buttonStyles = { root: { marginRight: 8 }}
  
 
  const [color, setColor] = React.useState(props.color);
  const [isEditable, setisEditable] = React.useState(props.pcfContext.parameters.CodigoColor.security?.editable)
  const [isOpen, setisOpen] = React.useState(false)

  const openPanel = React.useCallback(() => setisOpen(true),[])
  const dismissPanel = React.useCallback(() => setisOpen(false),[])
  const _updateColor = React.useCallback((ev: any, colorObj: IColor) => setColor(colorObj.str),[])
  const onRenderFooterContent =  React.useCallback(() => (
    <div>
      <PrimaryButton
        onClick={() => {
          props.updateColor(color)
          dismissPanel()
        }}
        styles={buttonStyles}
      >
        Seleccionar color
      </PrimaryButton>
    </div>
  ),[color])

  return (
    <div>  
      <PrimaryButton
        text="Select color"
        onClick={openPanel}
        allowDisabledFocus
        disabled={!isEditable}
      />     
      <PanelButton
        isOpen={isOpen}
        dismissPanel={dismissPanel}
        onRenderFooterContent={onRenderFooterContent}
        color={color}
        _updateColor={_updateColor}
      />
    </div>

  );
};

